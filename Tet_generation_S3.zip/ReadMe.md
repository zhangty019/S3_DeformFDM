# A short guidance of the *.tet generation for S^3 slicer

## Prerequisite

Please remesh the model uniformly and save it as a *.off file. E.g. bunny.off

## Usage

- Step 1:  Double click "run.bat" and type in "tetgen -Ya _ElementSize_ _ModelName_.off" and run it.
-- E.g. "tetgen -Ya4.0 bunny.off"

- Step 2: Double click the "MeshWorks.exe" and Drag the "_ModelName_.1.ele" into the UI.

- Step 3: After waiting a moment, the model will be generated. And then save it for the next use.

Cheers!

## S^3 Slicer

[Tianyu Zhang](https://www.linkedin.com/in/tianyu-zhang-49b8231b5/), Guoxin Fang, Yuming Huang, Neelotpal Dutta, Sylvain Lefebvre, Zekai Murat Kilic, and [Charlie C.L. Wang](https://mewangcl.github.io/), [*ACM Transactions on Graphics (SIGGRAPH Asia 2022)*, vol.41, no.6, article no.277 (15 pages), December 2022](https://dl.acm.org/doi/10.1145/3550454.3555516)

